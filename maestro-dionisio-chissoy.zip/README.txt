Sitio: Maestro Dionisio Chissoy — Sabiduría de la Selva Amazónica
Estructura preparada para publicar en Netlify o GitHub Pages.

Contenido:
- index.html
- assets/ (leaf.svg, fire.svg, forest.svg)

Instrucciones rápidas de despliegue:
- Netlify: arrastra la carpeta 'maestro-dionisio-chissoy' al panel 'Deploy > Drag and drop'.
- GitHub Pages: crea un repositorio y sube los archivos; activa Pages desde Settings > Pages > Source: main / root.